package registrofutbol.enums;

/**
 *
 * @author
 */
public enum Categoria {
    NINOS,
    JUVENIL,
    GENERAL,
    VETERANO
}

package registrofutbol.enums;

/**
 *
 * @author
 */
public enum Sexo {
    HOMBRE,
    MUJER
}

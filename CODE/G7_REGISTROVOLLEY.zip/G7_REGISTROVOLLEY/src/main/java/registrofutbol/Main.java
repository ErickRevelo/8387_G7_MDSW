package registrofutbol;

import registrofutbol.app.Aplicacion;

/**
 *
 * @author
 */
public class Main {
    public static void main(String[] args) {
        Aplicacion app = Aplicacion.getInstancia();
        app.iniciar();
    }
}

package registrofutbol.app;

import com.formdev.flatlaf.FlatLightLaf;
import java.util.HashMap;
import java.util.Map;
import javax.swing.UIManager;
import registrofutbol.controlador.ControladorAutentificacion;
import registrofutbol.controlador.ControladorCategorias;
import registrofutbol.controlador.ControladorDeportistas;
import registrofutbol.controlador.ControladorEquipos;
import registrofutbol.controlador.ControladorPerfil;
import registrofutbol.controlador.ControladorPrincipal;
import registrofutbol.controlador.ControladorReportes;
import registrofutbol.modelo.Usuario;

/**
 *
 * @author
 */
public class Aplicacion {
    // la instancia de esta aplicacion
    private static Aplicacion instancia = null;
    
    // el mapa de controladores
    private final Map<Class, Controlador> controladores = new HashMap<>();
    
    // el usuario actual logueado
    private Usuario usuarioActual = null;

    private Aplicacion() {}
    
    // nos cercioramos de que la aplicacion no sea instanciada 2 veces
    // con instanciar nos referimos a que no se cree 2 o mas objetos distintos de la misma clase
    public static Aplicacion getInstancia() {
        if (instancia == null) {
            instancia = new Aplicacion();
        }

        return instancia;
    }

    public void iniciar() {
        // registrar tema flatlaf
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
        }

        // registrar controladores
        registrarControlador(ControladorAutentificacion.class);
        registrarControlador(ControladorPrincipal.class);
        registrarControlador(ControladorPerfil.class);
        registrarControlador(ControladorCategorias.class);
        registrarControlador(ControladorDeportistas.class);
        registrarControlador(ControladorEquipos.class);
        registrarControlador(ControladorReportes.class);

        // obtener el controlador de autentificacion
        ControladorAutentificacion controladorAutentificacion = getControlador(ControladorAutentificacion.class);
        // mostrar ventana autentificacion
        controladorAutentificacion.mostrarVentana();
    }
    
    public void setUsuarioActual(Usuario usuario) {
        usuarioActual = usuario;
    }
    
    public Usuario getUsuarioActual() {
        return usuarioActual;
    }
    
    // metodo encargado de registrar un controlador mediante su nombre de clase
    // T se refiere a una clase que herede de la clase abstracta Controlador
    public <T extends Controlador> void registrarControlador(Class<T> claseControlador) {
        if (controladores.containsKey(claseControlador)) {
            return;
        }

        try {
            T controller = claseControlador
                .getConstructor(getClass())
                .newInstance(this);

            controladores.put(claseControlador, controller);
        } catch (Exception exception) {
            exception.printStackTrace(System.err);
        }
    }
    
    // metodo encargado de obtener un controlador por su tipo de clase
    // T se refiere a una clase que herede de la clase abstracta Controlador
    // de modo que este metodo retorna una clase "T" de tipo Controlador
    public <T extends Controlador> T getControlador(Class<T> controllerClass) {
        return (T) controladores.get(controllerClass);
    }
}

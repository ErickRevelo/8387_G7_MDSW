package registrofutbol.app;

/**
 * Clase abstracta para los modelos
 * @author
 */
public abstract class Modelo {
    public abstract String toCsv();
}

package registrofutbol.app;

/**
 * Clase utilizada para la comunicacion entre controlador y vista
 * @author
 */
public class EventoRespuesta {
    public static enum Estado {
        OK,
        ERROR,
        INFO
    }
    
    // mensaje del evento-respuesta
    private String mensaje;
    
    // estado del evento-respuesta (ok, error, informativo)
    private Estado estado;
    
    public static EventoRespuesta ok(String mensaje) {
        return new EventoRespuesta(mensaje, Estado.OK);
    }
    
    public static EventoRespuesta ok() {
        return ok("");
    }
    
    public static EventoRespuesta error(String mensaje) {
        return new EventoRespuesta(mensaje, Estado.ERROR);
    }
    
    public static EventoRespuesta error() {
        return ok("");
    }
    
    public EventoRespuesta(String mensaje, Estado estado) {
        this.mensaje = mensaje;
        this.estado = estado;
    }

    public String getMensaje() {
        return mensaje;
    }

    public Estado getEstado() {
        return estado;
    }
    
    public boolean esError() {
        return estado == Estado.ERROR;
    }
}

package registrofutbol.app;

/**
 * Clase utilizada para funciones utiles para la aplicacion
 * 
 * @author
 */
public class Utilidades {
    /**
     * Para validar una cedula se requiere sumar sus digitos pares e impares
     * sin el ultimo digito (digito verificador).
     * 
     * para mas informacion se puede ver el algoritmo en detalle en: https://www.jybaro.com/blog/cedula-de-identidad-ecuatoriana/
     * 
     * @param cedula
     * @return verdadero si la cedula es correcta, caso contrario falso
     */
    public static boolean validarCedula(String cedula) {
        if (cedula.length() != 10) {
            return false;
        }
        
        for (int i = 0; i < cedula.length(); i++) {
            if (!Character.isDigit(cedula.charAt(i))) {
                return false;
            }
        }
        
        int ultimoDigito = Character.getNumericValue((cedula.charAt(cedula.length() - 1)));
        int digito;
        int sumaPares = 0;
        int sumaImpares = 0;

        for (int i = 0; i < 9; i++) {
            digito = Character.getNumericValue(cedula.charAt(i));

            if ((i + 1) % 2 == 0) {
                sumaPares += digito;
            } else {
                sumaImpares += (digito * 2) > 9 ? (digito * 2) - 9 : (digito * 2);
            }
        }

        int total = sumaPares + sumaImpares;
        int superior = (10 - (total % 10)) + total;

        if ((total % 10) == 0) {
            return ultimoDigito == 0;
        }
        
        return ultimoDigito == (superior - total);
    }
}

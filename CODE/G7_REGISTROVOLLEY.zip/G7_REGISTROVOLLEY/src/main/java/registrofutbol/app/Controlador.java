package registrofutbol.app;

/**
 * Clase abstracta para un controlador
 * @author
 */
public abstract class Controlador {
    private final Aplicacion app;
    
    public Controlador(Aplicacion app) {
        this.app = app;
    }
    
    public Aplicacion getApp() {
        return app;
    }
}

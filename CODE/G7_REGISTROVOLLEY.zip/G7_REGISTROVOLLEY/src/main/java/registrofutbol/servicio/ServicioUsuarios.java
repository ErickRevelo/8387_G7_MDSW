package registrofutbol.servicio;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import registrofutbol.enums.Sexo;
import registrofutbol.modelo.Usuario;

/**
 *
 * @author
 */
public class ServicioUsuarios {
    private Path rutaBD = Paths.get("usuarios.txt");
    
    public ServicioUsuarios() {
        try {
            if (!rutaBD.toFile().exists()) {
                rutaBD.toFile().createNewFile();
            }
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
        }
    }
    
    public List<Usuario> obtenerTodos() {
        List<Usuario> usuarios = new ArrayList<>();
        
        try {
            List<String> csv = Files.readAllLines(rutaBD);
            
            for (String linea : csv) {
                String[] columnas = linea.split(",");
                
                String nombreUsuario = columnas[0];
                String nombre = columnas[1];
                String apellido = columnas[2];
                String password = columnas[3];
                String email = columnas[4];
                LocalDate fecha = LocalDate.parse(columnas[5]);
                Sexo sexo = Sexo.valueOf(columnas[6]);
                Usuario.Rol rol = Usuario.Rol.valueOf(columnas[7]);

                Usuario usuario = new Usuario(nombreUsuario, nombre, apellido, password, email, fecha, sexo, rol);
                usuarios.add(usuario);
            }
        } catch (IOException ex) {
            ex.printStackTrace(System.err);
        }
        
        return usuarios;
    }
    
    public Usuario obtener(String nombreUsuario) {
        List<Usuario> usuarios = obtenerTodos();
        
        for (Usuario usuario : usuarios) {
            if (usuario.getNombreUsuario().trim().equalsIgnoreCase(nombreUsuario.trim())) {
                return usuario;
            }
        }
        
        return null;
    }
    
    public void actualizar(Usuario actualizado) {
        List<Usuario> usuarios = obtenerTodos();
        List<String> csv = new ArrayList<>();
        String nombreUsuario = actualizado.getNombreUsuario().trim();
        
        for (Usuario usuario : usuarios) {
            if (usuario.getNombreUsuario().trim().equalsIgnoreCase(nombreUsuario)) {
                csv.add(actualizado.toCsv());
            } else {
                csv.add(usuario.toCsv());
            }
        }
        
        try {
            Files.write(rutaBD, csv, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
        }
    }
    
    public void guardar(Usuario usuario) {
        List<Usuario> usuarios = obtenerTodos();
        List<String> csv = new ArrayList<>();
        usuarios.add(usuario);
        
        for (Usuario u : usuarios) {
            csv.add(u.toCsv());
        }
        
        try {
            Files.write(rutaBD, csv, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
        }
    }
}

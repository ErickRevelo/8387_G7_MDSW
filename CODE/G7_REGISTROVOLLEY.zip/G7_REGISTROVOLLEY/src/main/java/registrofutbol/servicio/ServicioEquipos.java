package registrofutbol.servicio;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import registrofutbol.modelo.Equipo;

/**
 *
 * @author
 */
public class ServicioEquipos {
    private Path rutaBD = Paths.get("equipos.txt");
    
    public ServicioEquipos() {
        try {
            if (!rutaBD.toFile().exists()) {
                rutaBD.toFile().createNewFile();
            }
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
        }
    }
    
    public List<Equipo> obtenerTodos() {
        List<Equipo> equipos = new ArrayList<>();
        
        try {
            List<String> csv = Files.readAllLines(rutaBD);
            
            for (String linea : csv) {
                String[] columnas = linea.split(",");
                
                String codigo = columnas[0];
                String nombre = columnas[1];
                String nombreDirector = columnas[2];
                String apellidoDirector = columnas[3];
                String cedulaDirector = columnas[4];

                Equipo equipo = new Equipo(codigo, nombre, nombreDirector, apellidoDirector, cedulaDirector);
                equipos.add(equipo);
            }
        } catch (IOException ex) {
            ex.printStackTrace(System.err);
        }
        
        return equipos;
    }
    
    public Equipo obtener(String codigo) {
        List<Equipo> equipos = obtenerTodos();
        
        for (Equipo equipo : equipos) {
            if (equipo.getCodigo().trim().equalsIgnoreCase(codigo.trim())) {
                return equipo;
            }
        }
        
        return null;
    }
    
    public void actualizar(Equipo actualizado) {
        List<Equipo> equipos = obtenerTodos();
        List<String> csv = new ArrayList<>();
        String codigo = actualizado.getCodigo().trim();
        
        for (Equipo equipo : equipos) {
            if (equipo.getCodigo().trim().equalsIgnoreCase(codigo)) {
                csv.add(actualizado.toCsv());
            } else {
                csv.add(equipo.toCsv());
            }
        }
        
        try {
            Files.write(rutaBD, csv, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
        }
    }
    
    public void guardar(Equipo equipo) {
        List<Equipo> equipos = obtenerTodos();
        List<String> csv = new ArrayList<>();
        equipos.add(equipo);
        
        for (Equipo e : equipos) {
            csv.add(e.toCsv());
        }
        
        try {
            Files.write(rutaBD, csv, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
        }
    }
    
    public String generarCodigoUnico() {
        List<Equipo> equipos = obtenerTodos();
        Random random = new Random();
        String codigo;
        boolean repetido;
        
        do {
             codigo = String.format("EQU%05d", random.nextInt(1, 99999));
             repetido = false;
             
             for (Equipo equipo : equipos) {
                 if (equipo.getCodigo().equalsIgnoreCase(codigo)) {
                     repetido = true;
                     break;
                 }
             }
        } while (repetido);
        
        return codigo;
    }
}

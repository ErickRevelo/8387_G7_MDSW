package registrofutbol.servicio;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import registrofutbol.enums.Sexo;
import registrofutbol.modelo.Deportista;
import registrofutbol.modelo.Equipo;

/**
 * Clase responsable de hacer un CRUD para deportistas
 * 
 * @author
 */
public class ServicioDeportistas  {
    // ruta hacia el txt para la base de datos
    private Path rutaBD = Paths.get("deportistas.txt");
    
    // servicio de equipos
    private final ServicioEquipos servicioEquipos;
    
    public ServicioDeportistas(ServicioEquipos servicioEquipos) {
        // creamos el txt si no existe
        try {
            if (!rutaBD.toFile().exists()) {
                rutaBD.toFile().createNewFile();
            }
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
        }
        this.servicioEquipos =  servicioEquipos;
    }
    
    // metodo para obtener todos los deportistas de la base de datos
    public List<Deportista> obtenerTodos() {
        List<Deportista> deportistas = new ArrayList<>();
        
        try {
            List<String> csv = Files.readAllLines(rutaBD);
            
            for (String linea : csv) {
                String[] columnas = linea.split(",");
                
                String cedula = columnas[0];
                String nombre = columnas[1];
                String apellido = columnas[2];
                LocalDate fecha = LocalDate.parse(columnas[3]);
                Sexo sexo = Sexo.valueOf(columnas[4]);
                Equipo equipo = servicioEquipos.obtener(columnas[5]);

                Deportista deportista = new Deportista(cedula, nombre, apellido, fecha, sexo, equipo);
                deportistas.add(deportista);
            }
        } catch (IOException ex) {
            ex.printStackTrace(System.err);
        }
        
        return deportistas;
    }
    
    // metodo para obtener un deportista por cedula
    public Deportista obtener(String cedula) {
        List<Deportista> deportistas = obtenerTodos();
        
        for (Deportista deportista : deportistas) {
            if (deportista.getCedula().trim().equalsIgnoreCase(cedula.trim())) {
                return deportista;
            }
        }
        
        return null;
    }
    
    // metodo para actualizar un deportista
    public void actualizar(Deportista actualizado) {
        List<Deportista> deportistas = obtenerTodos();
        List<String> csv = new ArrayList<>();
        String cedula = actualizado.getCedula().trim();
        
        // recorremos los deportistas y los guardamos como lineas de texto
        for (Deportista deportista : deportistas) {
            if (deportista.getCedula().trim().equalsIgnoreCase(cedula)) {
                csv.add(actualizado.toCsv());
            } else {
                csv.add(deportista.toCsv());
            }
        }
        
        try {
            // escribimos las lineas en el archivo txt
            Files.write(rutaBD, csv, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
        }
    }
    
    // metodo para guardar un nuevo deportista en la base de datos
    public void guardar(Deportista deportista) {
        List<Deportista> deportistas = obtenerTodos();
        List<String> csv = new ArrayList<>();
        deportistas.add(deportista);
        
        // recorremos los deportistas y los guardamos como lineas de texto
        for (Deportista u : deportistas) {
            csv.add(u.toCsv());
        }
        
        try {
            // escribimos las lineas en el archivo txt
            Files.write(rutaBD, csv, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
        }
    }
}

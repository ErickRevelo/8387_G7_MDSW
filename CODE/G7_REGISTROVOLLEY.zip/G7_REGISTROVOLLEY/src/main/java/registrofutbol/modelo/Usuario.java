package registrofutbol.modelo;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import registrofutbol.app.Modelo;
import registrofutbol.enums.Sexo;

/**
 * Clase que representa un usuario
 * 
 * @author
 */
public class Usuario extends Modelo {
    public static enum Rol {
        SUPERADMIN,
        ADMIN,
        USUARIO
    }
    
    private String nombreUsuario;
    private String nombre;
    private String apellido;
    private String password;
    private String email;
    private LocalDate fechaNacimiento;
    private Sexo sexo;
    private Rol rol;

    public Usuario(String nombreUsuario, String nombre, String apellido, String password, String email, LocalDate fechaNacimiento, Sexo sexo, Rol rol) {
        this.nombreUsuario = nombreUsuario;
        this.nombre = nombre;
        this.apellido = apellido;
        this.password = password;
        this.email = email;
        this.fechaNacimiento = fechaNacimiento;
        this.sexo = sexo;
        this.rol = rol;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public Sexo getSexo() {
        return sexo;
    }

    public void setSexo(Sexo sexo) {
        this.sexo = sexo;
    }

    public Rol getRol() {
        return rol;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }
    
    @Override
    public String toCsv() {
        return nombreUsuario + "," + nombre + "," + apellido + "," + password 
            + "," + email + "," + fechaNacimiento.toString() + "," + sexo.name() + "," + rol.name();
    }
}

package registrofutbol.modelo;

import registrofutbol.app.Modelo;

/**
 * Clase que representa un Equipo
 * 
 * @author
 */
public class Equipo extends Modelo {
    private String codigo;
    private String nombre;
    private String nombreDirector;
    private String apellidoDirector;
    private String cedulaDirector;

    public Equipo(String codigo, String nombre, String nombreDirector, String apellidoDirector, String cedulaDirector) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.nombreDirector = nombreDirector;
        this.apellidoDirector = apellidoDirector;
        this.cedulaDirector = cedulaDirector;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombreDirector() {
        return nombreDirector;
    }

    public void setNombreDirector(String nombreDirector) {
        this.nombreDirector = nombreDirector;
    }

    public String getApellidoDirector() {
        return apellidoDirector;
    }

    public void setApellidoDirector(String apellidoDirector) {
        this.apellidoDirector = apellidoDirector;
    }

    public String getCedulaDirector() {
        return cedulaDirector;
    }

    public void setCedulaDirector(String cedulaDirector) {
        this.cedulaDirector = cedulaDirector;
    }

    @Override
    public String toCsv() {
        return codigo + "," + nombre + "," + nombreDirector + "," + apellidoDirector + "," + cedulaDirector;
    }
}

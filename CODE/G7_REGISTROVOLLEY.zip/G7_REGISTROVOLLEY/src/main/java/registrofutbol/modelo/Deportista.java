package registrofutbol.modelo;

import java.time.LocalDate;
import registrofutbol.app.Modelo;
import registrofutbol.enums.Sexo;

/**
 * Clase representando un deportista
 * 
 * @author
 */
public class Deportista extends Modelo {
    private String cedula;
    private String nombre;
    private String apellido;
    private LocalDate fechaNacimiento;
    private Sexo sexo;
    Equipo equipo;

    public Deportista(String cedula, String nombre, String apellido, LocalDate fechaNacimiento, Sexo sexo, Equipo equipo) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido = apellido;
        this.fechaNacimiento = fechaNacimiento;
        this.sexo = sexo;
        this.equipo = equipo;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public Sexo getSexo() {
        return sexo;
    }

    public void setSexo(Sexo sexo) {
        this.sexo = sexo;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    @Override
    public String toCsv() {
        return cedula + "," + nombre + "," + apellido + "," 
            + fechaNacimiento.toString() + "," + sexo.name() + "," + equipo.getCodigo();
    }
}

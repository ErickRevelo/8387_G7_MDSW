package registrofutbol.controlador;

import registrofutbol.app.Aplicacion;
import registrofutbol.app.Controlador;
import registrofutbol.servicio.ServicioDeportistas;
import registrofutbol.servicio.ServicioEquipos;
import registrofutbol.vista.VentanaPrincipal;
import registrofutbol.vista.VistaReportes;

/**
 * Controlador encargado de gestionar la vista de reportes
 * @author
 */
public class ControladorReportes extends Controlador {
    private ServicioEquipos servicioEquipos = new ServicioEquipos();
    private ServicioDeportistas servicioDeportistas = new ServicioDeportistas(servicioEquipos);
    
    private VentanaPrincipal ventana = getApp()
        .getControlador(ControladorPrincipal.class)
        .getVentanaPrincipal();
    
    public ControladorReportes(Aplicacion app) {
        super(app);
    }
    
    public void mostrarVista() {
        VistaReportes vista = new VistaReportes(this);
        vista.cargarDatos(servicioEquipos.obtenerTodos(), servicioDeportistas.obtenerTodos());
        ventana.mostrarVista(vista);
    }
}

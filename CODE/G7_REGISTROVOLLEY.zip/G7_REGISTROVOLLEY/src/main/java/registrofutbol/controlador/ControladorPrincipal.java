package registrofutbol.controlador;

import registrofutbol.app.Aplicacion;
import registrofutbol.app.Controlador;
import registrofutbol.vista.VentanaPrincipal;

/**
 * Controlador encargado de gestionar la ventana principal y su navegacion del menu
 * 
 * @author
 */
public class ControladorPrincipal extends Controlador {
    private final VentanaPrincipal ventanaPrincipal = new VentanaPrincipal(this);
    
    public ControladorPrincipal(Aplicacion app) {
        super(app);
    }
    
    public VentanaPrincipal getVentanaPrincipal() {
        return ventanaPrincipal;
    }
    
    // metodo encargado de mostrar la ventana principal
    public void mostrarVentana() {
        ventanaPrincipal.actualizarInformacionUsuario();
        ventanaPrincipal.setLocationRelativeTo(null);
        ventanaPrincipal.setVisible(true);
    }

    // metodo encargado de navegar en la ventana principal
    // dependiendo que opcion del menu sea seleccionada
    // se llamara a un controlador y a un metodo para mostrar una vista
    public void navegar(String ruta) {
        switch (ruta) {
            case "menu::perfil": {
                ControladorPerfil controlador = getApp().getControlador(ControladorPerfil.class);
                controlador.mostrarVista();
            } break;
            case "menu::categorias": {
                ControladorCategorias controlador = getApp().getControlador(ControladorCategorias.class);
                controlador.mostrarVista();
            } break;
            case "menu::deportistas::registrar": {
                ControladorDeportistas controlador = getApp().getControlador(ControladorDeportistas.class);
                controlador.mostrarVistaAgregarDeportista();
            } break;
            case "menu::deportistas::ver": {
                ControladorDeportistas controlador = getApp().getControlador(ControladorDeportistas.class);
                controlador.mostrarVistaVerDeportistas();
            } break;
            case "menu::equipos::registrar": {
                ControladorEquipos controlador = getApp().getControlador(ControladorEquipos.class);
                controlador.mostrarVistaAgregarEquipo();
            } break;
            case "menu::equipos::ver": {
                ControladorEquipos controlador = getApp().getControlador(ControladorEquipos.class);
                controlador.mostrarVistaVerEquipos();
            } break;
            case "menu::reportes": {
                ControladorReportes controlador = getApp().getControlador(ControladorReportes.class);
                controlador.mostrarVista();
            } break;
            default: System.err.println("Ruta invalida"); break;
        }
    }
    
    // metodo que cierra sesion de usuario, cierra la ventana principal y muestra la ventana de autentificacion
    public void desloguearse() {
        Aplicacion app = getApp();
        ControladorAutentificacion controladorAutentificacion 
            = app.getControlador(ControladorAutentificacion.class);
        
        ventanaPrincipal.setVisible(false);
        ventanaPrincipal.mostrarVista(null);
        controladorAutentificacion.mostrarVentana();
    }
}

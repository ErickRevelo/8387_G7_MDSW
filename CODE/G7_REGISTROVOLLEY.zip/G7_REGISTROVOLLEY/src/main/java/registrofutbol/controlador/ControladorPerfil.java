package registrofutbol.controlador;

import java.time.LocalDate;
import java.util.regex.Pattern;
import org.mindrot.jbcrypt.BCrypt;
import registrofutbol.app.Aplicacion;
import registrofutbol.app.Controlador;
import registrofutbol.app.EventoRespuesta;
import registrofutbol.modelo.Usuario;
import registrofutbol.servicio.ServicioUsuarios;
import registrofutbol.vista.VentanaPrincipal;
import registrofutbol.vista.VistaPerfil;

/**
 * Controlador encargado de gestionar la vista 'Perfil' y sus operaciones
 * @author
 */
public class ControladorPerfil extends Controlador {
    // servicio de usuarios
    private ServicioUsuarios servicioUsuarios = new ServicioUsuarios();
    
    // ventana principal
    private VentanaPrincipal ventana = getApp()
        .getControlador(ControladorPrincipal.class)
        .getVentanaPrincipal();
    
    public ControladorPerfil(Aplicacion app) {
        super(app);
    }

    // mostramos la vista en la ventana principal
    void mostrarVista() {
        VistaPerfil vista = new VistaPerfil(this);
        ventana.mostrarVista(vista);
    }
    
    // metodo encargado de guardar un usuario en la base de datos
    public EventoRespuesta guardarUsuario(Usuario usuario) {
        Usuario usuarioActual = getApp().getUsuarioActual();
        String nombre = usuario.getNombre();
        String apellido = usuario.getApellido();
        String email = usuario.getEmail();
        String password = usuario.getPassword();
        
        // verificamos si el nombre contiene solo letras y espacios
        if (nombre.isEmpty() || !nombre.matches("^[a-zA-Z']{2,}(\\s[a-zA-Z']{2,})?$")) {
            return EventoRespuesta.error("El nombre es invalido");
        }
        
        // verificamos si el apellido contiene solo letras y espacios
        if (apellido.isEmpty() || !apellido.matches("^[a-zA-Z']{2,}(\\s[a-zA-Z']{2,})?$")) {
            return EventoRespuesta.error("El apellido es invalido");
        }
        
        // patron para validar un correo
        Pattern patronEmailValido = Pattern
            .compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
        
        // comprobamos que el correo tenga un formato valido
        if (!patronEmailValido.matcher(email).find()) {
            return EventoRespuesta.error("Email invalido");
        }
        
        // comprobamos la longitud de la contraseña
        if (!password.isEmpty() && password.length() < 8) {
            return EventoRespuesta.error("La contraseña debe ser mayor o igual a 8 caracteres");
        }
        
        // comprobamos que la fecha no sea mayor a la fecha actual
        if (usuario.getFechaNacimiento().isAfter(LocalDate.now())) {
            return EventoRespuesta.error("La fecha es incorrecta");
        }
        
        // si el password esta vacio quiere decir que no se ingreso un nuevo password
        // por lo que se utilizara el mismo
        if (!password.isEmpty()) {
            usuario.setPassword(BCrypt.hashpw(usuario.getPassword(), BCrypt.gensalt()));
        } else {
            // en caso de que el password no este vacio entonces definimos el nuevo password
            usuario.setPassword(usuarioActual.getPassword());
        }
        
        // actualizamos el usuario en la base de datos
        servicioUsuarios.actualizar(usuario);
        
        // colocamos el nuevo usuario
        getApp().setUsuarioActual(usuario);
        
        // le notificamos a la vista que el usuario fue guardado
        return EventoRespuesta.ok("Cambios guardados con exito");
    }
}

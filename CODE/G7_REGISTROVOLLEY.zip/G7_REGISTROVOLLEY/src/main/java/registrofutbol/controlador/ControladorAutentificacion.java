package registrofutbol.controlador;

import java.time.LocalDate;
import org.mindrot.jbcrypt.BCrypt;
import registrofutbol.app.Controlador;
import registrofutbol.app.Aplicacion;
import registrofutbol.app.EventoRespuesta;
import registrofutbol.enums.Sexo;
import registrofutbol.modelo.Usuario;
import registrofutbol.servicio.ServicioUsuarios;
import registrofutbol.vista.VentanaAutentificacion;

/**
 * Controlador encargado de la ventana de autentificacion y registro junto con sus operaciones
 * 
 * @author
 */
public class ControladorAutentificacion extends Controlador {
    // ventana de autentificacion
    VentanaAutentificacion ventanaAutentificacion = new VentanaAutentificacion(this);
    
    // servicio de usuarios
    ServicioUsuarios servicioUsuarios = new ServicioUsuarios();

    public ControladorAutentificacion(Aplicacion app) {
        super(app);
        crearAdminPorDefecto();
    }

    public void mostrarVentana() {
        ventanaAutentificacion.setLocationRelativeTo(null);
        ventanaAutentificacion.setVisible(true);
    }
    
    // metodo encargado de loguear un usuario con contraseña
    public EventoRespuesta ingresar(String nombreUsuario, String password) {
        // obtenemos un usuario por su nombre de usuario
        Usuario usuario = servicioUsuarios.obtener(nombreUsuario);

        // si el usuario es nulo entonces mostramos un error en la vista
        if (usuario == null) {
            return EventoRespuesta.error("Usuario no encontrado");
        }
        
        // si la contraseña no coincide mostramos un error
        if (!BCrypt.checkpw(password, usuario.getPassword())) {
            return EventoRespuesta.error("La contraseña no coincide");
        }
        
        // definimos el usuario actual logueado
        getApp().setUsuarioActual(usuario);
        getApp().getControlador(ControladorPrincipal.class).mostrarVentana();
        
        // enviar una respuesta "ok" a la vista
        return EventoRespuesta.ok();
    }
    
    // metodo encargado de crear un super administrador, en caso de que no exista en la base de datos
    private void crearAdminPorDefecto() {
        Usuario admin = servicioUsuarios.obtener("jhonatan");

        if (admin == null) {
            String salt = BCrypt.gensalt();
            Usuario usuario = new Usuario(
                "jhonatan",
                "Jhonathan",
                "Jhonathan",
                BCrypt.hashpw("Fs#230401_%", salt),
                "Jhonathan@example.com",
                LocalDate.of(2000, 01, 01),
                Sexo.HOMBRE,
                Usuario.Rol.SUPERADMIN
            );
            servicioUsuarios.guardar(usuario);
        }
    }

    public void registrarUsuario(Usuario usuario) {
        servicioUsuarios.guardar(usuario);
    }
}

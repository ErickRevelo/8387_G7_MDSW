package registrofutbol.controlador;

import java.util.List;
import registrofutbol.app.Aplicacion;
import registrofutbol.app.Controlador;
import registrofutbol.app.EventoRespuesta;
import registrofutbol.modelo.Equipo;
import registrofutbol.servicio.ServicioEquipos;
import registrofutbol.vista.VentanaPrincipal;
import registrofutbol.vista.VistaAgregarEquipo;
import registrofutbol.vista.VistaVerEquipos;

/**
 * Controlador responsable de gestionar las vistas 'ver equipos' y 'agregar equipo'
 * 
 * @author
 */
public class ControladorEquipos extends Controlador {
    // servicio de equipos
    private ServicioEquipos servicioEquipos = new ServicioEquipos();
    
    // ventana principal
    private VentanaPrincipal ventana = getApp()
        .getControlador(ControladorPrincipal.class)
        .getVentanaPrincipal();
    
    public ControladorEquipos(Aplicacion app) {
        super(app);
    }
    
    public void mostrarVistaVerEquipos() {
        // obtenemos todos los equipos guardados en la base de datos
        List<Equipo> equipos = servicioEquipos.obtenerTodos();
        
        // creamos la vista
        VistaVerEquipos vista = new VistaVerEquipos(this);
        
        // cargamos los equipos en la vista
        vista.cargarEquipos(equipos);
        
        // mostramos la vista en la ventana
        ventana.mostrarVista(vista);
    }
    
    public void mostrarVistaAgregarEquipo() {
        // creamos la vista
        VistaAgregarEquipo vista = new VistaAgregarEquipo(this);
        
        // mostramos la vista en la ventana
        ventana.mostrarVista(vista);
    }

    public EventoRespuesta agregarEquipo(Equipo equipo) {
        // cargamos los equipos de la base de datos
        List<Equipo> equipos = servicioEquipos.obtenerTodos();
        
        // recorremos los equipos y verificamos que el codigo ni la cedula este duplicada
        for (Equipo e : equipos) {
            if (e.getCodigo().equalsIgnoreCase(equipo.getCodigo())) {
                return EventoRespuesta.error("El codigo ingresado ya ha sido registrado");
            }
            
            if (e.getCedulaDirector().equalsIgnoreCase(equipo.getCedulaDirector())) {
                return EventoRespuesta.error("La cedula del director ingresada ya ha sido registrada");
            }
        }
        
        // definimos un codigo aleatorio para el equipo
        equipo.setCodigo(servicioEquipos.generarCodigoUnico());
        
        // guardamos el equipo en la base de datos
        servicioEquipos.guardar(equipo);
        
        // le comunicamos a la vista que la operacion fue correcta
        return EventoRespuesta.ok();
    }
}

package registrofutbol.controlador;

import java.util.List;
import registrofutbol.app.Aplicacion;
import registrofutbol.app.Controlador;
import registrofutbol.app.EventoRespuesta;
import registrofutbol.modelo.Deportista;
import registrofutbol.modelo.Equipo;
import registrofutbol.servicio.ServicioDeportistas;
import registrofutbol.servicio.ServicioEquipos;
import registrofutbol.vista.VentanaPrincipal;
import registrofutbol.vista.VistaAgregarDeportista;
import registrofutbol.vista.VistaVerDeportistas;

/**
 * Controlador encargado de gestionar las vistas "ver deportistas" y "agregar deportistas"
 * 
 * @author
 */
public class ControladorDeportistas extends Controlador {
    // definimos los servicios necesarios
    private ServicioEquipos servicioEquipos = new ServicioEquipos();
    private ServicioDeportistas servicioDeportistas = new ServicioDeportistas(servicioEquipos);
    
    // definimos la ventana principal
    private VentanaPrincipal ventana = getApp()
        .getControlador(ControladorPrincipal.class)
        .getVentanaPrincipal();
    
    public ControladorDeportistas(Aplicacion app) {
        super(app);
    }
    
    // metodo encargado de mostrar la vista 'ver deportistas'
    public void mostrarVistaVerDeportistas() {
        // cargamos los deportistas de la base de datos
        List<Deportista> deportistas = servicioDeportistas.obtenerTodos();
        
        // creamos la vista
        VistaVerDeportistas vista = new VistaVerDeportistas(this);
        
        // cargamos los deportistas en la vista
        vista.cargarDeportistas(deportistas);
        
        // mostramos la vista en la ventana principal
        ventana.mostrarVista(vista);
    }
    
    // metodo encargado de mostrar la vista 'agregar deportista'
    public void mostrarVistaAgregarDeportista() {
        // cargamos los equipos de la base de datos
        List<Equipo> equipos = servicioEquipos.obtenerTodos();
        
        // creamos la vista
        VistaAgregarDeportista vista = new VistaAgregarDeportista(this);
        
        // cargamos los equipos en la vista
        vista.cargarEquipos(equipos);
        
        // mostramos la vista en la ventana principal
        ventana.mostrarVista(vista);
    }
    
    // metodo encargado de mostrar la vista 'agregar deportista'
    public EventoRespuesta agregarDeportista(Deportista deportista) {
        // obtenemos los deportistas en la base de datos
        List<Deportista> deportistas = servicioDeportistas.obtenerTodos();
        
        // reocorremos los deportistas en busca de una cedula duplicada
        for (Deportista d : deportistas) {
            // si se encuentra una cedula duplicada, se regresa un error a la vista
            if (d.getCedula().equalsIgnoreCase(deportista.getCedula())) {
                return EventoRespuesta.error("La cedula ingresada ya ha sido registrada");
            }
        }
        
        // guardamos el deportista en la base de datos
        servicioDeportistas.guardar(deportista);
        
        // le notificamos a la vista que la operacion fue correcta
        return EventoRespuesta.ok();
    }
}

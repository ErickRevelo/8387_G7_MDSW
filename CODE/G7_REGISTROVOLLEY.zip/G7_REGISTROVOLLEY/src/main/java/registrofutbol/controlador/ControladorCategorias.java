package registrofutbol.controlador;

import registrofutbol.app.Aplicacion;
import registrofutbol.app.Controlador;
import registrofutbol.servicio.ServicioDeportistas;
import registrofutbol.servicio.ServicioEquipos;
import registrofutbol.vista.VentanaPrincipal;
import registrofutbol.vista.VistaCategorias;

/**
 * Controlador encargado de gestionar la vista categorias
 * 
 * @author
 */
public class ControladorCategorias extends Controlador {
    private ServicioDeportistas servicioDeportistas 
        = new ServicioDeportistas(new ServicioEquipos());
    
    // ventana principal de la aplicacion
    private VentanaPrincipal ventana = getApp()
        .getControlador(ControladorPrincipal.class)
        .getVentanaPrincipal();
    
    public ControladorCategorias(Aplicacion app) {
        super(app);
    }
    
    public void mostrarVista() {
        VistaCategorias vista = new VistaCategorias(this);
        ventana.mostrarVista(vista);
    }
    
    public ServicioDeportistas getServicioDeportistas() {
        return servicioDeportistas;
    }
}
